package pipette.painter;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Created by ordagan on 17.9.2016.
 */
public class Menu extends Application {

    public void start(Stage primaryStage) throws Exception {

    }
}