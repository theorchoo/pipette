package pipette.painter;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Screen;
import javafx.stage.WindowEvent;

import pipette.server.PipetteServer;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;

public class Main extends Application {
    static Controller controller;
    PipetteServer server;
    Scene menuScene;
    Stage stage;
    private ArrayList<Scene> paintingScenes = new ArrayList<>();
    private ArrayList<File> files = new ArrayList<>();
    Rectangle2D screenSize = Screen.getPrimary().getVisualBounds();

    private void parsePaintFolder() throws Exception {
        File folder = new File("/Users/ordagan/Documents/pipette/JavaFX/src/pipette/painter/paints");
        File[] paintings = folder.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.getName().substring(pathname.getName().lastIndexOf('.')).equals(".fxml");
            }
        });
        for (File file : paintings) {
            Parent parent = FXMLLoader.load(getClass().getResource("paints/" + file.getName()));
            parent.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    fill(event.getX(), event.getY(), "#ff0000");
                }
            });
            paintingScenes.add(new Scene(parent,screenSize.getWidth(), screenSize.getHeight()));
            files.add(file);
        }
    }

    private Scene getMenuScene() {
        BorderPane pane = new BorderPane();
        HBox hBox = new HBox();
        hBox.getStyleClass().add("topBar");
        Text headline = new Text("Choose Painting:");
        headline.setFont(Font.font("Arial", FontWeight.BOLD, 30));
        headline.getStyleClass().add("topBarHeadline");
        hBox.getChildren().addAll(headline);
        pane.setTop(hBox);

        FlowPane flow = new FlowPane();
        flow.setVgap(4);
        flow.setHgap(4);
        flow.setStyle("-fx-background-color: FFFFFF;");

        for (int i = 0; i < files.size(); i++) {
            final int j = i;
            Button button = new Button(files.get(i).getName().substring(0,files.get(i).getName().lastIndexOf('.')));
            button.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    switchToScene(j);
                }
            });
            flow.getChildren().add(button);
        }

        pane.setCenter(flow);
        return new Scene(pane,screenSize.getWidth(), screenSize.getHeight());
    }

    public void switchToScene(int index) {
         stage.setScene(paintingScenes.get(index));
         stage.getScene().getStylesheets().add("/Users/ordagan/Documents/pipette/JavaFX/src/pipette/painter/style.css");
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        server = new PipetteServer(this);
        server.startServer(8080);
        stage = primaryStage;
        // stage.setMaximized(true);

        parsePaintFolder();
        menuScene = getMenuScene();

        stage.setTitle("Pipette");
        stage.setScene(menuScene);
        stage.getScene().getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                server.stop();
            }
        });

        stage.show();
    }

    public void pipetteAction(Color color) {
        System.out.println(color.getRed() + " ; " + color.getGreen() + " ; " + color.getBlue());
    }

    public void pipetteButton() {
        System.out.println("button pressed");
    }

    public void fill(double x, double y, String rgbColor) {
        controller.fill(x,y, Color.web(rgbColor));
    }

    public static void main(String[] args) {
        launch(args);
    }
}
