import com.sun.glass.ui.Pixels;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import jdk.nashorn.internal.runtime.ECMAException;
import org.openkinect.freenect.*;
import sun.awt.image.ImageDecoder;
import sun.awt.image.InputStreamImageSource;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class Testing extends Application {
    static BufferedImage image;
    Context ctx = null;
    Device dev = null;
    ImageView imageView;
    BufferedImage outRgb;

    public void start(Stage primaryStage) throws Exception {
        BorderPane borderPane = new BorderPane();
        imageView = new ImageView();
        borderPane.setCenter(imageView);

        primaryStage.setScene(new Scene(borderPane,800,600));

        // DECLARATIONS

        // INITIALIZE DEVICE
        ctx = Freenect.createContext();
        if (ctx.numDevices() > 0) {
            dev = ctx.openDevice(0);
        } else {
            System.err.println("No kinects detected.  Exiting.");
            System.exit(0);
        }

        // TILT UP, DOWN, & RETURN
        dev.setTiltAngle(0);

        dev.setVideoFormat(VideoFormat.RGB);
        VideoHandler videoHandler = new VideoHandler() {
            @Override
            public void onFrameReceived(FrameMode frameMode, ByteBuffer byteBuffer, int i) {
                processRgb(frameMode,byteBuffer,i);
            }
        };
        dev.startVideo(videoHandler);

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                if (ctx != null)
                    if (dev != null) {
                        dev.close();
                    }
                ctx.shutdown();
            }
        });
        // SHUT DOWN
        primaryStage.show();
    }

    protected void processRgb( FrameMode mode, ByteBuffer frame, int timestamp ) {
        if( mode.getVideoFormat() != VideoFormat.RGB ) {
            System.out.println("Bad rgb format!");
        }
        System.out.println("Got rgb!   "+timestamp);
        if( outRgb == null ) {
            //rgb.reshape(mode.getWidth(),mode.getHeight());
            outRgb = new BufferedImage(mode.getWidth(),mode.getHeight(),BufferedImage.TYPE_INT_RGB);
            try {
                outRgb = ImageIO.read(new ByteArrayInputStream(frame.array()));
            } catch (Exception e) {
                System.out.println("ec");
            }
            WritableImage img = new WritableImage(outRgb.getWidth(),outRgb.getHeight());
            SwingFXUtils.toFXImage(outRgb,img);
            imageView.setImage(img);
        }

    }

    public static void main(String[] args) throws InterruptedException {

        launch(args);

    }

}
